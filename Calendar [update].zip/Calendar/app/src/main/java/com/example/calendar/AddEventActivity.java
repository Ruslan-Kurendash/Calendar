package com.example.calendar;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEventActivity extends AppCompatActivity {
    private EditText eventDateEditText;
    private EditText eventDescriptionEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        eventDateEditText = findViewById(R.id.eventDateEditText);
        eventDescriptionEditText = findViewById(R.id.eventDescriptionEditText);

        Button saveButton = findViewById(R.id.saveButton);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveEvent();
            }
        });
    }


    private void saveEvent() {
        String date = eventDateEditText.getText().toString();
        String description = eventDescriptionEditText.getText().toString();

        if (!date.isEmpty() && !description.isEmpty()) {
            if (isValidDateFormat(date)) {
                Intent resultIntent = new Intent();
                resultIntent.putExtra("date", date);
                resultIntent.putExtra("description", description);
                setResult(RESULT_OK, resultIntent);
                finish();
            } else {
                Toast.makeText(this, "Неправильний формат дати. Використовуйте формат 'рік-місяць-день'", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Будь ласка, введіть дату та опис події", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean isValidDateFormat(String date) {
        // Перевірка на правильний формат дати (рік-місяць-день)
        return date.matches("\\d{4}-\\d{2}-\\d{2}");
    }
}

