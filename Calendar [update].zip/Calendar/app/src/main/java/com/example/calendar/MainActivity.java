package com.example.calendar;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public void addEvent(Event event) {
        events.add(event);
    }

    private static final int ADD_EVENT_REQUEST_CODE = 1;
    private List<Event> events;
    private TextView eventDescriptionTextView;

    // Зберігаємо події у форматі "дата" -> "опис події"
    private Map<String, String> eventMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addEventButton = findViewById(R.id.addEventButton);
        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddEventActivity();
            }
        });

        events = new ArrayList<>();
        // Додати початкові події до списку events
        addInitialEvents();


        // Додаємо різні свята та події
        events.add(new Event(2024, 1, 1, "Новий Рік"));
        events.add(new Event(2024, 1, 6, "Хрещення Господнє"));
        events.add(new Event(2024, 1,21,"My birthday"));
        events.add(new Event(2024, 2, 2, "Стрітення Господнє"));
        events.add(new Event(2024, 3, 8, "Міжнародний Жіночий день"));
        events.add(new Event(2024, 3, 25, "Благовіщення Пресвятої Богородиці"));
        events.add(new Event(2024, 4, 28, "Вербна неділя"));
        events.add(new Event(2024, 5, 1, "День праці"));
        events.add(new Event(2024, 5, 5, "Воскресіння Господнє (Великдень)"));
        events.add(new Event(2024, 5, 8, "День пам'яті та перемоги над нацизмом у Другій світовій війні 1939-1945 років"));
        events.add(new Event(2024, 5, 25, "Третє віднайдення голови Івана Хрестителя"));
        events.add(new Event(2024, 6, 13, "Вознесіння Господнє"));
        events.add(new Event(2024, 6, 23, "Трійця"));
        events.add(new Event(2024, 6, 28, "День Конституції України"));
        events.add(new Event(2024, 6, 29, "святих апостолів Петра і Павла"));
        events.add(new Event(2024, 7, 15, "День Української Державності"));
        events.add(new Event(2024, 8, 6, "Преображення Господнє"));
        events.add(new Event(2024, 8, 15, "Успіння Пресвятої Богородиці"));
        events.add(new Event(2024, 8, 24, "День Незалежності України"));
        events.add(new Event(2024, 9, 8, "Різдво Пресвятої Богородиці"));
        events.add(new Event(2024, 10, 1, "Покрова Пресвятої Богородиці"));
        events.add(new Event(2024, 11, 21, "Введення в храм Пресвятої Богородиці"));
        events.add(new Event(2024, 12, 6, "День святого Миколая"));
        events.add(new Event(2024, 12, 25, "Різдво Христове"));

        CalendarView calendarView = findViewById(R.id.calendarView);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {

                // Отримуємо опис події для вибраної дати
                String eventDescription = getEventDescription(year, month + 1, dayOfMonth);
                if (eventDescription != null) {
                    // Показуємо опис події, якщо вона існує
                    Toast.makeText(MainActivity.this, eventDescription, Toast.LENGTH_SHORT).show();
                } else {
                    // Показуємо повідомлення, якщо для обраної дати події відсутні
                    Toast.makeText(MainActivity.this, "Подій на цей день немає", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void addInitialEvents() {
    }

    private String getEventDescription(int year, int month, int day) {
        // Отримати опис події за датою
        for (Event event : events) {
            if (event.getYear() == year && event.getMonth() == month && event.getDay() == day) {
                return event.getDescription();
            }
        }
        return null;
    }

    private void openAddEventActivity() {
        Intent intent = new Intent(this, AddEventActivity.class);
        startActivityForResult(intent, ADD_EVENT_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_EVENT_REQUEST_CODE && resultCode == RESULT_OK) {
            String date = data.getStringExtra("date");
            String description = data.getStringExtra("description");
            // Додати нову подію до списку events
            String[] dateParts = date.split("-");
            int year = Integer.parseInt(dateParts[0]);
            int month = Integer.parseInt(dateParts[1]);
            int day = Integer.parseInt(dateParts[2]);
            Event event = new Event(year, month, day, description);
            events.add(event);
            Toast.makeText(this, "Подія додана: " + date + ", " + description, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Додавання події скасоване", Toast.LENGTH_SHORT).show();
        }
    }
}
